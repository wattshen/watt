import const
const.value=5
print const.value
const.value=6
