i=5
print i
i+=1
print i
i+=2
print i
i+=3
print i
