#ת���
print 'It\'s a dog!'

print "hello boy\nhello boy"
