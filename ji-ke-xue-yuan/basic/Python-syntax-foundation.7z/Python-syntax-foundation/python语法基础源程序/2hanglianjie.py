a="777"
 print a
