import pickle
print "777"


