i=7
print i