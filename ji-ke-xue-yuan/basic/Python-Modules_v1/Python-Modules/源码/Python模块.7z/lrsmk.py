def func1():
	print "hello"
def func2():
	print "I am fine"