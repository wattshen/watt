from django.contrib import admin
from myLesson.models import *

admin.site.register(MySite)
