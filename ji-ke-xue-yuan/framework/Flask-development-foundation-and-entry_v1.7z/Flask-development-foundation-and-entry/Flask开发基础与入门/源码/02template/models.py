
class User(object):
    def __init__(self, user_id , user_name):
        self.user_id = user_id
        self.user_name = user_name